export const environment = {
  production: false,
  supabaseUrl: 'https://fgdcgpscgsfkarggwvlf.supabase.co',
  supabaseKey: 'sb_publishable_6vv5kKw9RYgX0J2OkaAJRw__HqWSFht',
};
